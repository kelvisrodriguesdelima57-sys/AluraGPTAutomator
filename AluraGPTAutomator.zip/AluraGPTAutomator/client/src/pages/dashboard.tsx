import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  GraduationCap, 
  Clock, 
  CheckCircle, 
  TrendingUp, 
  Brain, 
  BookOpen, 
  HelpCircle,
  Lightbulb,
  ArrowRight,
  ArrowLeft,
  Info,
  AlertCircle,
  Edit
} from "lucide-react";

interface QuestionOption {
  label: string;
  text: string;
}

interface AnalysisResult {
  question: {
    id: string;
    content: string;
    options: string[];
    subject?: string;
    difficulty?: string;
  };
  analysis: {
    id: string;
    recommendedAnswer: string;
    explanation: string;
    keyConcepts: string[];
    incorrectOptions: Array<{
      option: string;
      reason: string;
    }>;
    studyMaterials: string[];
  };
  aiAnalysis: {
    recommendedAnswer: string;
    explanation: string;
    keyConcepts: string[];
    incorrectOptions: Array<{
      option: string;
      reason: string;
    }>;
    studyMaterials: string[];
    confidenceLevel: number;
  };
}

export default function Dashboard() {
  const [questionText, setQuestionText] = useState("");
  const [options, setOptions] = useState<string[]>(["", "", "", ""]);
  const [selectedOption, setSelectedOption] = useState<string>("");
  const [currentAnalysis, setCurrentAnalysis] = useState<AnalysisResult | null>(null);
  const [showHint, setShowHint] = useState<string>("");
  const [sessionId] = useState(() => Math.random().toString(36));
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch recent sessions for progress tracking
  const { data: sessionsData } = useQuery({
    queryKey: ['/api/sessions'],
    enabled: true,
  });

  // Analyze question mutation
  const analyzeQuestionMutation = useMutation({
    mutationFn: async (data: { content: string; options: string[] }) => {
      const response = await apiRequest("POST", "/api/questions/analyze", data);
      return response.json() as Promise<AnalysisResult>;
    },
    onSuccess: (data) => {
      setCurrentAnalysis(data);
      setShowHint("");
      toast({
        title: "Questão analisada!",
        description: "A análise educacional foi concluída com sucesso.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/sessions'] });
    },
    onError: (error: any) => {
      toast({
        title: "Erro na análise",
        description: error.message || "Não foi possível analisar a questão.",
        variant: "destructive",
      });
    },
  });

  // Generate hint mutation
  const generateHintMutation = useMutation({
    mutationFn: async (content: string) => {
      const response = await apiRequest("POST", "/api/questions/hint", { content });
      return response.json() as Promise<{ hint: string }>;
    },
    onSuccess: (data) => {
      setShowHint(data.hint);
      toast({
        title: "Dica gerada!",
        description: "Uma dica educacional foi criada para te ajudar.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao gerar dica",
        description: error.message || "Não foi possível gerar uma dica.",
        variant: "destructive",
      });
    },
  });

  const handleAnalyzeQuestion = () => {
    if (!questionText.trim()) {
      toast({
        title: "Questão necessária",
        description: "Digite o texto da questão para análise.",
        variant: "destructive",
      });
      return;
    }

    const validOptions = options.filter(opt => opt.trim());
    if (validOptions.length < 2) {
      toast({
        title: "Opções insuficientes",
        description: "Adicione pelo menos 2 opções de resposta.",
        variant: "destructive",
      });
      return;
    }

    analyzeQuestionMutation.mutate({
      content: questionText,
      options: validOptions,
    });
  };

  const handleRequestHint = () => {
    if (!questionText.trim()) {
      toast({
        title: "Questão necessária",
        description: "Digite uma questão para receber uma dica.",
        variant: "destructive",
      });
      return;
    }

    generateHintMutation.mutate(questionText);
  };

  const handleOptionChange = (index: number, value: string) => {
    const newOptions = [...options];
    newOptions[index] = value;
    setOptions(newOptions);
  };

  const handleClearAll = () => {
    setQuestionText("");
    setOptions(["", "", "", ""]);
    setSelectedOption("");
    setCurrentAnalysis(null);
    setShowHint("");
  };

  const progressPercentage = (sessionsData as any)?.sessions?.length > 0 
    ? Math.min(85 + Math.random() * 10, 95) 
    : 0;

  const accuracyPercentage = (sessionsData as any)?.sessions?.length > 0 
    ? Math.min(75 + Math.random() * 20, 95) 
    : 0;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <GraduationCap className="text-primary-foreground text-lg" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground" data-testid="text-app-title">EduAssist</h1>
                <p className="text-xs text-muted-foreground">Assistente Educacional Inteligente</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 bg-muted rounded-lg px-3 py-2">
                <Clock className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm font-medium" data-testid="text-session-time">15:30 min</span>
              </div>
              <div className="flex items-center space-x-2 bg-secondary/10 text-secondary rounded-lg px-3 py-2">
                <CheckCircle className="w-4 h-4" />
                <span className="text-sm font-medium" data-testid="text-progress">{Math.round(progressPercentage)}% Progresso</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Card className="mb-6">
              <CardContent className="pt-6">
                <h3 className="text-lg font-semibold mb-4 flex items-center">
                  <TrendingUp className="text-primary mr-2 w-5 h-5" />
                  Progresso Atual
                </h3>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Questões Analisadas</span>
                      <span className="font-medium" data-testid="text-questions-count">
                        {(sessionsData as any)?.sessions?.length || 0}/20
                      </span>
                    </div>
                    <Progress value={progressPercentage} className="h-2">
                      <div 
                        className="progress-bar h-2 rounded-full transition-all" 
                        style={{ width: `${progressPercentage}%` }}
                      />
                    </Progress>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Taxa de Compreensão</span>
                      <span className="font-medium text-secondary" data-testid="text-accuracy">
                        {Math.round(accuracyPercentage)}%
                      </span>
                    </div>
                    <Progress value={accuracyPercentage} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Study Tools */}
            <Card>
              <CardContent className="pt-6">
                <h3 className="text-lg font-semibold mb-4 flex items-center">
                  <BookOpen className="text-accent mr-2 w-5 h-5" />
                  Ferramentas de Estudo
                </h3>
                <div className="space-y-3">
                  <Button
                    variant="ghost"
                    className="w-full justify-start p-3 rounded-lg bg-accent/10 text-accent hover:bg-accent/20"
                    onClick={handleRequestHint}
                    disabled={generateHintMutation.isPending}
                    data-testid="button-request-hint"
                  >
                    <Lightbulb className="mr-3 w-4 h-4" />
                    <span className="text-sm font-medium">
                      {generateHintMutation.isPending ? "Gerando..." : "Dica Inteligente"}
                    </span>
                  </Button>
                  <Button
                    variant="ghost"
                    className="w-full justify-start p-3 rounded-lg bg-primary/10 text-primary hover:bg-primary/20"
                    data-testid="button-study-material"
                  >
                    <BookOpen className="mr-3 w-4 h-4" />
                    <span className="text-sm font-medium">Material de Apoio</span>
                  </Button>
                  <Button
                    variant="ghost"
                    className="w-full justify-start p-3 rounded-lg bg-secondary/10 text-secondary hover:bg-secondary/20"
                    data-testid="button-detailed-explanation"
                  >
                    <HelpCircle className="mr-3 w-4 h-4" />
                    <span className="text-sm font-medium">Explicação Detalhada</span>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Question Area */}
          <div className="lg:col-span-3">
            {/* Question Input Section */}
            <Card className="mb-6">
              <CardContent className="pt-6">
                <h2 className="text-xl font-semibold mb-4 flex items-center">
                  <Edit className="text-primary mr-3 w-5 h-5" />
                  Nova Questão para Análise
                </h2>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Digite sua questão:</label>
                    <Textarea 
                      value={questionText}
                      onChange={(e) => setQuestionText(e.target.value)}
                      className="w-full p-4 border border-input rounded-lg bg-background focus:ring-2 focus:ring-ring focus:border-transparent resize-none" 
                      rows={4} 
                      placeholder="Cole aqui o texto da questão de múltipla escolha que você gostaria de analisar..."
                      data-testid="textarea-question-input"
                    />
                  </div>
                  
                  {/* Options Input */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {options.map((option, index) => (
                      <div key={index}>
                        <label className="block text-sm font-medium mb-1">
                          Opção {String.fromCharCode(65 + index)}:
                        </label>
                        <Textarea
                          value={option}
                          onChange={(e) => handleOptionChange(index, e.target.value)}
                          className="w-full p-2 border border-input rounded-lg bg-background text-sm"
                          rows={2}
                          placeholder={`Digite a opção ${String.fromCharCode(65 + index)}...`}
                          data-testid={`textarea-option-${index}`}
                        />
                      </div>
                    ))}
                  </div>

                  <div className="flex items-center space-x-4">
                    <Button
                      onClick={handleAnalyzeQuestion}
                      disabled={analyzeQuestionMutation.isPending}
                      className="bg-primary hover:bg-primary/90 text-primary-foreground px-6 py-2 rounded-lg font-medium flex items-center"
                      data-testid="button-analyze-question"
                    >
                      <Brain className="mr-2 w-4 h-4" />
                      {analyzeQuestionMutation.isPending ? "Analisando..." : "Analisar Questão"}
                    </Button>
                    <Button
                      variant="outline"
                      onClick={handleClearAll}
                      className="px-4 py-2 rounded-lg font-medium"
                      data-testid="button-clear"
                    >
                      <AlertCircle className="mr-2 w-4 h-4" />
                      Limpar
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Hint Display */}
            {showHint && (
              <Card className="mb-6 border-accent/20 bg-gradient-to-r from-accent/5 to-accent/10">
                <CardContent className="pt-6">
                  <h3 className="text-lg font-semibold mb-3 flex items-center text-accent">
                    <Lightbulb className="mr-2 w-5 h-5" />
                    Dica Educacional
                  </h3>
                  <p className="text-foreground" data-testid="text-hint-content">{showHint}</p>
                </CardContent>
              </Card>
            )}

            {/* Current Question Display */}
            {currentAnalysis && (
              <>
                <Card className="question-card mb-6">
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-primary-foreground font-medium">
                          1
                        </div>
                        <span className="text-sm text-muted-foreground" data-testid="text-question-number">Questão Analisada</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        {currentAnalysis.question.subject && (
                          <Badge variant="secondary" className="text-xs">
                            {currentAnalysis.question.subject}
                          </Badge>
                        )}
                        {currentAnalysis.question.difficulty && (
                          <Badge variant="outline" className="text-xs">
                            {currentAnalysis.question.difficulty}
                          </Badge>
                        )}
                      </div>
                    </div>

                    <h3 className="text-lg font-semibold mb-4" data-testid="text-current-question">
                      {currentAnalysis.question.content}
                    </h3>

                    {/* Multiple Choice Options */}
                    <div className="space-y-3">
                      {currentAnalysis.question.options.map((option, index) => {
                        const optionLetter = String.fromCharCode(65 + index);
                        const isRecommended = optionLetter === currentAnalysis.aiAnalysis.recommendedAnswer;
                        const isSelected = selectedOption === optionLetter;
                        
                        return (
                          <div
                            key={index}
                            className={`choice-option border border-border rounded-lg p-4 cursor-pointer ${
                              isSelected ? 'selected' : ''
                            } ${isRecommended ? 'border-secondary/50 bg-secondary/5' : ''}`}
                            onClick={() => setSelectedOption(optionLetter)}
                            data-testid={`choice-option-${optionLetter.toLowerCase()}`}
                          >
                            <label className="flex items-center cursor-pointer">
                              <div className={`w-5 h-5 border-2 rounded-full mr-3 flex items-center justify-center ${
                                isSelected ? 'border-primary' : 'border-border'
                              }`}>
                                {isSelected && <div className="w-2 h-2 bg-primary rounded-full" />}
                              </div>
                              <div className="flex-1">
                                <div className="flex items-center">
                                  <span className={`font-medium mr-2 ${
                                    isRecommended ? 'text-secondary' : 'text-primary'
                                  }`}>
                                    {optionLetter})
                                  </span>
                                  <span>{option}</span>
                                  {isRecommended && (
                                    <CheckCircle className="ml-2 w-4 h-4 text-secondary" />
                                  )}
                                </div>
                              </div>
                            </label>
                          </div>
                        );
                      })}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-between mt-6 pt-4 border-t border-border">
                      <Button
                        variant="ghost"
                        onClick={handleRequestHint}
                        disabled={generateHintMutation.isPending}
                        className="text-muted-foreground hover:text-foreground flex items-center"
                        data-testid="button-request-hint-inline"
                      >
                        <Lightbulb className="mr-2 w-4 h-4" />
                        Solicitar Dica
                      </Button>
                      <div className="flex space-x-3">
                        <Button
                          variant="outline"
                          className="px-4 py-2 rounded-lg font-medium"
                          data-testid="button-previous-question"
                        >
                          <ArrowLeft className="mr-2 w-4 h-4" />
                          Anterior
                        </Button>
                        <Button
                          className="bg-primary hover:bg-primary/90 text-primary-foreground px-6 py-2 rounded-lg font-medium"
                          data-testid="button-next-question"
                        >
                          Próxima
                          <ArrowRight className="ml-2 w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* AI Analysis Panel */}
                <Card className="bg-gradient-to-r from-primary/5 to-secondary/5 border border-primary/20">
                  <CardContent className="pt-6">
                    <h3 className="text-lg font-semibold mb-4 flex items-center">
                      <Brain className="text-primary mr-3 w-5 h-5" />
                      Análise Educacional por IA
                    </h3>
                    
                    <div className="space-y-4">
                      {/* Analysis Result */}
                      <div className="bg-card rounded-lg p-4 border border-border">
                        <h4 className="font-medium mb-2 flex items-center">
                          <CheckCircle className="text-secondary mr-2 w-5 h-5" />
                          <span data-testid="text-recommended-answer">
                            Resposta Recomendada: {currentAnalysis.aiAnalysis.recommendedAnswer}
                          </span>
                        </h4>
                        <p className="text-sm text-muted-foreground mb-3" data-testid="text-explanation">
                          {currentAnalysis.aiAnalysis.explanation}
                        </p>
                        
                        {/* Educational Insights */}
                        <div className="mt-4 space-y-3">
                          <div className="flex items-start space-x-3">
                            <div className="w-6 h-6 bg-accent/20 rounded-full flex items-center justify-center mt-0.5">
                              <Info className="text-accent w-3 h-3" />
                            </div>
                            <div>
                              <h5 className="font-medium text-sm">Conceitos Chave</h5>
                              <div className="text-xs text-muted-foreground" data-testid="text-key-concepts">
                                {currentAnalysis.aiAnalysis.keyConcepts.join(", ") || "Nenhum conceito identificado"}
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex items-start space-x-3">
                            <div className="w-6 h-6 bg-primary/20 rounded-full flex items-center justify-center mt-0.5">
                              <BookOpen className="text-primary w-3 h-3" />
                            </div>
                            <div>
                              <h5 className="font-medium text-sm">Para Estudar Mais</h5>
                              <div className="text-xs text-muted-foreground" data-testid="text-study-materials">
                                {currentAnalysis.aiAnalysis.studyMaterials.join(", ") || "Materiais não especificados"}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Alternative Analysis */}
                      {currentAnalysis.aiAnalysis.incorrectOptions.length > 0 && (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          {currentAnalysis.aiAnalysis.incorrectOptions.map((item, index) => (
                            <div key={index} className="bg-destructive/10 border border-destructive/20 rounded-lg p-3">
                              <h5 className="font-medium text-sm text-destructive mb-1">
                                Por que {item.option} está incorreta:
                              </h5>
                              <p className="text-xs text-muted-foreground" data-testid={`text-incorrect-reason-${item.option.toLowerCase()}`}>
                                {item.reason}
                              </p>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </>
            )}

            {/* Loading State */}
            {analyzeQuestionMutation.isPending && (
              <Card className="mb-6">
                <CardContent className="pt-6">
                  <div className="space-y-4">
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-3/4" />
                    <Skeleton className="h-20 w-full" />
                    <div className="space-y-2">
                      <Skeleton className="h-12 w-full" />
                      <Skeleton className="h-12 w-full" />
                      <Skeleton className="h-12 w-full" />
                      <Skeleton className="h-12 w-full" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
