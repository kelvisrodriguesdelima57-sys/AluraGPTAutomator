import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { GraduationCap, Brain, BookOpen, Target } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="gradient-bg text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <div className="flex justify-center mb-6">
              <div className="w-20 h-20 bg-white/20 rounded-2xl flex items-center justify-center">
                <GraduationCap className="h-12 w-12 text-white" />
              </div>
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6">
              EduAssist
            </h1>
            <p className="text-xl sm:text-2xl mb-4 opacity-90">
              Assistente Educacional Inteligente
            </p>
            <p className="text-lg mb-8 opacity-80 max-w-2xl mx-auto">
              Potencialize seus estudos com análises inteligentes de questões de múltipla escolha, 
              dicas educacionais e acompanhamento de progresso personalizado.
            </p>
            <Link href="/dashboard">
              <Button 
                size="lg" 
                className="bg-white text-primary hover:bg-white/90 text-lg px-8 py-3"
                data-testid="button-start-studying"
              >
                <Brain className="mr-2 h-5 w-5" />
                Começar a Estudar
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">
              Como o EduAssist te Ajuda
            </h2>
            <p className="text-lg text-muted-foreground">
              Ferramentas inteligentes para maximizar seu aprendizado
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Brain className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Análise Inteligente</h3>
                <p className="text-muted-foreground">
                  IA avançada analisa suas questões e fornece explicações detalhadas, 
                  identificando conceitos-chave e pontos de atenção.
                </p>
              </CardContent>
            </Card>

            {/* Feature 2 */}
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <BookOpen className="h-6 w-6 text-secondary" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Dicas Educacionais</h3>
                <p className="text-muted-foreground">
                  Receba dicas sutis que te guiam na direção certa sem entregar 
                  a resposta, estimulando seu pensamento crítico.
                </p>
              </CardContent>
            </Card>

            {/* Feature 3 */}
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Target className="h-6 w-6 text-accent" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Acompanhamento</h3>
                <p className="text-muted-foreground">
                  Monitore seu progresso com estatísticas detalhadas e 
                  identifique áreas que precisam de mais atenção.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Call to Action */}
      <div className="bg-muted py-16">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-foreground mb-4">
            Pronto para Turbinar seus Estudos?
          </h2>
          <p className="text-lg text-muted-foreground mb-8">
            Junte-se a milhares de estudantes que já estão usando a inteligência artificial 
            para melhorar sua performance acadêmica.
          </p>
          <Link href="/dashboard">
            <Button 
              size="lg" 
              className="bg-primary hover:bg-primary/90 text-primary-foreground text-lg px-8 py-3"
              data-testid="button-get-started"
            >
              Começar Agora - É Grátis
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
