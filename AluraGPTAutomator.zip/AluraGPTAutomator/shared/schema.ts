import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, jsonb, uuid } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const questions = pgTable("questions", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  content: text("content").notNull(),
  options: jsonb("options").$type<string[]>().notNull(), // Array of choice options
  subject: text("subject"),
  difficulty: text("difficulty"),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

export const analyses = pgTable("analyses", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  questionId: uuid("question_id").notNull().unique().references(() => questions.id),
  recommendedAnswer: text("recommended_answer"),
  explanation: text("explanation"),
  keyConcepts: jsonb("key_concepts").$type<string[]>(), // Array of educational concepts
  incorrectOptions: jsonb("incorrect_options").$type<{option: string, reason: string}[]>(), // Analysis of why options are wrong
  studyMaterials: jsonb("study_materials").$type<{title: string, url?: string, type: string}[]>(), // Suggested materials
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

export const sessions = pgTable("sessions", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  questionsAnswered: integer("questions_answered").default(0),
  correctAnswers: integer("correct_answers").default(0),
  totalTime: integer("total_time").default(0), // in seconds
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

export const insertQuestionSchema = createInsertSchema(questions).omit({
  id: true,
  createdAt: true,
});

export const insertAnalysisSchema = createInsertSchema(analyses).omit({
  id: true,
  createdAt: true,
});

export const insertSessionSchema = createInsertSchema(sessions).omit({
  id: true,
  createdAt: true,
});

export type Question = typeof questions.$inferSelect;
export type InsertQuestion = z.infer<typeof insertQuestionSchema>;
export type Analysis = typeof analyses.$inferSelect;
export type InsertAnalysis = z.infer<typeof insertAnalysisSchema>;
export type Session = typeof sessions.$inferSelect;
export type InsertSession = z.infer<typeof insertSessionSchema>;
