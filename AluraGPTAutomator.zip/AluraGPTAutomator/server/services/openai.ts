import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.API_KEY || ""
});

export interface QuestionAnalysis {
  recommendedAnswer: string;
  explanation: string;
  keyConcepts: string[];
  incorrectOptions: Array<{
    option: string;
    reason: string;
  }>;
  studyMaterials: string[];
  confidenceLevel: number;
}

export async function analyzeQuestion(
  questionContent: string,
  options: string[]
): Promise<QuestionAnalysis> {
  try {
    const prompt = `
Você é um assistente educacional especializado em análise de questões de múltipla escolha em português brasileiro. 
Analise a seguinte questão e forneça uma resposta educacional detalhada em formato JSON.

QUESTÃO:
${questionContent}

OPÇÕES:
${options.map((option, index) => `${String.fromCharCode(65 + index)}) ${option}`).join('\n')}

Forneça sua análise em formato JSON com a seguinte estrutura:
{
  "recommendedAnswer": "letra da resposta recomendada (A, B, C, D, etc.)",
  "explanation": "explicação detalhada da resposta correta em português",
  "keyConcepts": ["conceito1", "conceito2", "conceito3"],
  "incorrectOptions": [
    {
      "option": "A",
      "reason": "motivo pelo qual esta opção está incorreta"
    }
  ],
  "studyMaterials": ["material de estudo sugerido 1", "material 2"],
  "confidenceLevel": 0.95
}

IMPORTANTE: Foque em educação e aprendizagem, não apenas na resposta correta. Explique os conceitos por trás da questão.
`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "Você é um assistente educacional que fornece análises detalhadas de questões de múltipla escolha para estudantes brasileiros. Sempre responda em português brasileiro."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      max_tokens: 1000,
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    return {
      recommendedAnswer: result.recommendedAnswer || "A",
      explanation: result.explanation || "Análise não disponível",
      keyConcepts: result.keyConcepts || [],
      incorrectOptions: result.incorrectOptions || [],
      studyMaterials: result.studyMaterials || [],
      confidenceLevel: Math.max(0, Math.min(1, result.confidenceLevel || 0.5)),
    };
  } catch (error) {
    console.error("Erro ao analisar questão com OpenAI:", error);
    throw new Error("Falha ao analisar a questão. Verifique sua conexão e tente novamente.");
  }
}

export async function generateHint(questionContent: string): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "Você é um tutor educacional que fornece dicas sutis para ajudar estudantes a pensarem na direção correta, sem dar a resposta diretamente."
        },
        {
          role: "user",
          content: `Forneça uma dica educacional sutil para ajudar o estudante a pensar sobre esta questão (não dê a resposta direta):\n\n${questionContent}`
        }
      ],
      max_tokens: 200,
    });

    return response.choices[0].message.content || "Pense sobre os conceitos fundamentais relacionados ao tema da questão.";
  } catch (error) {
    console.error("Erro ao gerar dica:", error);
    throw new Error("Não foi possível gerar uma dica no momento.");
  }
}
