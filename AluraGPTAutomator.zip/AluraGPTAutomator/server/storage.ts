import { type Question, type InsertQuestion, type Analysis, type InsertAnalysis, type Session, type InsertSession, questions, analyses, sessions } from "@shared/schema";
import { randomUUID } from "crypto";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // Questions
  createQuestion(question: InsertQuestion): Promise<Question>;
  getQuestion(id: string): Promise<Question | undefined>;
  
  // Analyses
  createAnalysis(analysis: InsertAnalysis): Promise<Analysis>;
  getAnalysisByQuestionId(questionId: string): Promise<Analysis | undefined>;
  
  // Sessions
  createSession(session: InsertSession): Promise<Session>;
  getSession(id: string): Promise<Session | undefined>;
  updateSession(id: string, updates: Partial<InsertSession>): Promise<Session>;
  getRecentSessions(limit?: number): Promise<Session[]>;
  
  // Transactions
  createQuestionWithAnalysis(
    question: InsertQuestion, 
    analysis: Omit<InsertAnalysis, 'questionId'>
  ): Promise<{ question: Question; analysis: Analysis }>;
}

export class DatabaseStorage implements IStorage {
  async createQuestion(insertQuestion: InsertQuestion): Promise<Question> {
    const [question] = await db.insert(questions).values(insertQuestion).returning();
    return question;
  }

  async getQuestion(id: string): Promise<Question | undefined> {
    const [question] = await db.select().from(questions).where(eq(questions.id, id));
    return question;
  }

  async createAnalysis(insertAnalysis: InsertAnalysis): Promise<Analysis> {
    const [analysis] = await db.insert(analyses).values(insertAnalysis).returning();
    return analysis;
  }

  async getAnalysisByQuestionId(questionId: string): Promise<Analysis | undefined> {
    const [analysis] = await db
      .select()
      .from(analyses)
      .where(eq(analyses.questionId, questionId));
    return analysis;
  }

  async createSession(insertSession: InsertSession): Promise<Session> {
    const [session] = await db.insert(sessions).values(insertSession).returning();
    return session;
  }

  async getSession(id: string): Promise<Session | undefined> {
    const [session] = await db.select().from(sessions).where(eq(sessions.id, id));
    return session;
  }

  async updateSession(id: string, updates: Partial<InsertSession>): Promise<Session> {
    const [session] = await db
      .update(sessions)
      .set(updates)
      .where(eq(sessions.id, id))
      .returning();
    
    if (!session) {
      throw new Error("Session not found");
    }
    
    return session;
  }

  async getRecentSessions(limit = 10): Promise<Session[]> {
    return await db
      .select()
      .from(sessions)
      .orderBy(desc(sessions.createdAt))
      .limit(limit);
  }

  async createQuestionWithAnalysis(
    insertQuestion: InsertQuestion, 
    insertAnalysis: Omit<InsertAnalysis, 'questionId'>
  ): Promise<{ question: Question; analysis: Analysis }> {
    return await db.transaction(async (tx) => {
      // Create question first
      const [question] = await tx.insert(questions).values(insertQuestion).returning();
      
      // Create analysis with the question ID
      const [analysis] = await tx.insert(analyses).values({
        ...insertAnalysis,
        questionId: question.id,
      }).returning();
      
      return { question, analysis };
    });
  }
}

export const storage = new DatabaseStorage();
