import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { analyzeQuestion, generateHint } from "./services/openai";
import { insertQuestionSchema, insertAnalysisSchema, insertSessionSchema } from "@shared/schema";
import { z } from "zod";

const analyzeQuestionRequestSchema = z.object({
  content: z.string().min(10, "Questão deve ter pelo menos 10 caracteres"),
  options: z.array(z.string()).min(2, "Deve haver pelo menos 2 opções").max(6, "Máximo de 6 opções"),
  subject: z.string().optional(),
  difficulty: z.string().optional(),
});

const generateHintRequestSchema = z.object({
  content: z.string().min(10, "Questão deve ter pelo menos 10 caracteres"),
});

const updateSessionRequestSchema = z.object({
  questionsAnswered: z.number().optional(),
  correctAnswers: z.number().optional(), 
  totalTime: z.number().optional(),
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Analyze a question with AI
  app.post("/api/questions/analyze", async (req, res) => {
    try {
      const { content, options, subject, difficulty } = analyzeQuestionRequestSchema.parse(req.body);
      
      // Get AI analysis first - fail fast if AI service is down
      const aiAnalysis = await analyzeQuestion(content, options);
      
      // Create question and analysis in a single transaction
      const { question, analysis } = await storage.createQuestionWithAnalysis(
        {
          content,
          options,
          subject,
          difficulty,
        },
        {
          recommendedAnswer: aiAnalysis.recommendedAnswer,
          explanation: aiAnalysis.explanation,
          keyConcepts: aiAnalysis.keyConcepts,
          incorrectOptions: aiAnalysis.incorrectOptions,
          studyMaterials: aiAnalysis.studyMaterials,
        }
      );
      
      res.json({
        question,
        analysis,
        aiAnalysis,
      });
    } catch (error: any) {
      console.error("Erro ao analisar questão:", error);
      res.status(400).json({ 
        message: error.message || "Erro ao analisar questão"
      });
    }
  });

  // Generate hint for a question
  app.post("/api/questions/hint", async (req, res) => {
    try {
      const { content } = generateHintRequestSchema.parse(req.body);
      
      const hint = await generateHint(content);
      
      res.json({ hint });
    } catch (error: any) {
      console.error("Erro ao gerar dica:", error);
      res.status(400).json({ 
        message: error.message || "Erro ao gerar dica"
      });
    }
  });

  // Get question and its analysis
  app.get("/api/questions/:id", async (req, res) => {
    try {
      const { id } = req.params;
      
      const question = await storage.getQuestion(id);
      if (!question) {
        return res.status(404).json({ message: "Questão não encontrada" });
      }
      
      const analysis = await storage.getAnalysisByQuestionId(id);
      
      res.json({
        question,
        analysis,
      });
    } catch (error: any) {
      console.error("Erro ao buscar questão:", error);
      res.status(500).json({ 
        message: "Erro interno do servidor"
      });
    }
  });

  // Create a new study session
  app.post("/api/sessions", async (req, res) => {
    try {
      const sessionData = insertSessionSchema.parse(req.body);
      
      const session = await storage.createSession(sessionData);
      
      res.json({ session });
    } catch (error: any) {
      console.error("Erro ao criar sessão:", error);
      res.status(400).json({ 
        message: error.message || "Erro ao criar sessão"
      });
    }
  });

  // Update study session
  app.patch("/api/sessions/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = updateSessionRequestSchema.parse(req.body);
      
      const session = await storage.updateSession(id, updates);
      
      res.json({ session });
    } catch (error: any) {
      console.error("Erro ao atualizar sessão:", error);
      res.status(400).json({ 
        message: error.message || "Erro ao atualizar sessão"
      });
    }
  });

  // Get session by ID
  app.get("/api/sessions/:id", async (req, res) => {
    try {
      const { id } = req.params;
      
      const session = await storage.getSession(id);
      if (!session) {
        return res.status(404).json({ message: "Sessão não encontrada" });
      }
      
      res.json({ session });
    } catch (error: any) {
      console.error("Erro ao buscar sessão:", error);
      res.status(500).json({ 
        message: "Erro interno do servidor"
      });
    }
  });

  // Get recent sessions for dashboard
  app.get("/api/sessions", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      
      const sessions = await storage.getRecentSessions(limit);
      
      res.json({ sessions });
    } catch (error: any) {
      console.error("Erro ao buscar sessões:", error);
      res.status(500).json({ 
        message: "Erro interno do servidor"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
